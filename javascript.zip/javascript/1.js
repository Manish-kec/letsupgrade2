var str="this is my first javascript code";
var a=str.indexOf("my");
console.log(a);