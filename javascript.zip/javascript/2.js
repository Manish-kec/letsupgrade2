
var t=prompt("minute:");
console.log("time in seconds",t*60);
