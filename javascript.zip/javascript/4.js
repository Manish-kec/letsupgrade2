let arr=['papaya','guava','orange','turnip']
for(elements of arr)
{
  if(elements.toLowerCase().includes('a'))
  {
    console.log(elements);
  }
}